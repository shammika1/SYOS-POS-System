﻿namespace SYOSSytem.DTO;

public class ReshelvingReportDTO
{
    public string ItemCode { get; set; }
    public string ItemName { get; set; }
    public int Quantity { get; set; }
}