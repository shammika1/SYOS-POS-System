﻿using System.Windows.Controls;

namespace SYOS.WPF.Views;

public partial class ItemManagementView : UserControl
{
    public ItemManagementView()
    {
        InitializeComponent();
    }
}