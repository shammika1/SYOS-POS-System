﻿using Microsoft.AspNetCore.SignalR;
using SYOS.Server.DataGateway;
using SYOS.Server.Hubs;
using SYOS.Shared.DTO;
using SYOS.Shared.Interfaces;
using System.Data;
using SYOS.Server.Exceptions;

namespace SYOS.Server.Services
{
    public class ItemService : IItemService
    {
        private readonly ItemGateway _itemGateway;
        private readonly IHubContext<SYOSHub> _hubContext;

        public ItemService(ItemGateway itemGateway, IHubContext<SYOSHub> hubContext)
        {
            _itemGateway = itemGateway;
            _hubContext = hubContext;
        }

        public async Task<ItemDTO> GetItemAsync(string itemCode)
        {
            return await _itemGateway.GetItemAsync(itemCode);
        }

        public async Task<List<ItemDTO>> GetAllItemsAsync()
        {
            return await _itemGateway.GetAllItemsAsync();
        }

        public async Task AddItemAsync(ItemDTO item)
        {
            await _itemGateway.AddItemAsync(item);
            await _hubContext.Clients.All.SendAsync("ReceiveItemUpdate", item);
        }

        public async Task EditItemAsync(ItemDTO item)
        {
            try
            {
                await _itemGateway.EditItemAsync(item);
                await _hubContext.Clients.All.SendAsync("ReceiveItemUpdate", item);
            }
            catch (ConcurrencyException)

            {
                // Fetch the latest version from the database
                var latestItem = await _itemGateway.GetItemAsync(item.ItemCode);
                await _hubContext.Clients.All.SendAsync("ReceiveItemUpdate", latestItem);
                throw; // Rethrow the exception to be handled by the controller
            }
        }

        public async Task DeleteItemAsync(string itemCode)
        {
            await _itemGateway.DeleteItemAsync(itemCode);
            await _hubContext.Clients.All.SendAsync("ReceiveItemDelete", itemCode);
        }
    }
}