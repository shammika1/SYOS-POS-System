﻿namespace SYOSSytem.Command;

public interface ICommand
{
    void Execute();
}