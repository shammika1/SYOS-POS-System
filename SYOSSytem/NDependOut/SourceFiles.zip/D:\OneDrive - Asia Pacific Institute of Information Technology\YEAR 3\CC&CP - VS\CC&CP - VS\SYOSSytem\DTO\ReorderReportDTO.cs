﻿namespace SYOSSytem.DTO;

public class ReorderReportDTO
{
    public string ItemCode { get; set; }
    public string ItemName { get; set; }
    public int RemainingQuantity { get; set; }
}