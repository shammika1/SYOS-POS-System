﻿using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Template
{
    public class StockReport : Report
    {
        protected override List<object> GetReportData()
        {
            return reportGateway.GetStockReport().Cast<object>().ToList();
        }

        protected override void DisplayReport(List<object> data)
        {
            var stockData = data.Cast<StockReportDTO>().ToList();
            Console.WriteLine("Stock Report:");
            Console.WriteLine("Stock ID\tItem Code\tItem Name\tQuantity\tExpiry Date");
            foreach (var item in stockData)
            {
                Console.WriteLine($"{item.StockID}\t{item.ItemCode}\t{item.ItemName}\t{item.Quantity}\t{item.ExpiryDate?.ToString("yyyy-MM-dd") ?? "N/A"}");
            }
        }
    }
}
