﻿using SYOSSytem.Command;
using SYOSSytem.DataGateway;
using SYOSSytem.DTO;
using SYOSSytem.State;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Factory
{
    public static class CommandFactory
    {
        public static ICommand CreateProcessSaleCommand(BillingContext context)
        {
            return new ProcessSaleCommand(context);
        }
    }

}
