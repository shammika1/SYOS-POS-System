﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Composite
{
    public class CategoryComposite : IItemComponent
    {
        public string CategoryName { get; private set; }
        private List<IItemComponent> _components = new List<IItemComponent>();

        public CategoryComposite(string categoryName)
        {
            CategoryName = categoryName;
        }

        public void Add(IItemComponent component)
        {
            _components.Add(component);
        }

        public void Remove(IItemComponent component)
        {
            _components.Remove(component);
        }

        public void Display(int depth)
        {
            Console.WriteLine(new string('-', depth) + CategoryName);
            foreach (var component in _components)
            {
                component.Display(depth + 2);
            }
        }

        public List<IItemComponent> GetComponents()
        {
            return _components;
        }
    }

}
