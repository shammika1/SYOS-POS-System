﻿using SYOSSytem.Builder;
using SYOSSytem.DataGateway;
using SYOSSytem.Decorator;
using SYOSSytem.DTO;
using SYOSSytem.Factory;
using SYOSSytem.State;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class ProcessSaleCommand : ICommand
    {
        private BillingContext _context;

        public ProcessSaleCommand(BillingContext context)
        {
            _context = context;
        }

        public void Execute()
        {
            decimal totalPrice = _context.BillItems.Sum(item => item.TotalPrice);
            decimal discountedPrice = totalPrice - _context.Discount;
            decimal changeAmount = _context.CashTendered - discountedPrice;

            BillDTO bill = new BillBuilder()
                .SetBillID(null)  // BillID will be generated
                .SetDate(DateTime.Now)
                .SetTotalPrice(totalPrice)
                .SetDiscount(_context.Discount)
                .SetCashTendered(_context.CashTendered)
                .SetChangeAmount(changeAmount)
                .Build();

            // Apply discount decorator
            BillDTO discountedBill = new DiscountDecorator(bill, _context.Discount);

            _context.BillGateway.AddBill(discountedBill);

            foreach (var billItem in _context.BillItems)
            {
                billItem.BillID = discountedBill.BillID;
                _context.BillItemGateway.AddBillItem(billItem);
            }

            _context.InventoryFacade.UpdateShelfQuantitiesAfterSale(_context.BillItems);

            DisplayBill(_context.BillItems, discountedBill);

            Console.WriteLine("Bill generated and saved successfully.");
        }

        private void DisplayBill(List<BillItemDTO> billItems, BillDTO bill)
        {
            Console.WriteLine("\nBill Summary:");
            Console.WriteLine("Item Name\tQuantity\tPrice\tTotal Price");

            foreach (var billItem in billItems)
            {
                Console.WriteLine($"{billItem.ItemName}\t{billItem.Quantity}\t{billItem.TotalPrice / billItem.Quantity}\t{billItem.TotalPrice}");
            }

            Console.WriteLine($"Total Price: {bill.TotalPrice + bill.Discount}");
            Console.WriteLine($"Discount: {bill.Discount}");
            Console.WriteLine($"Total after Discount: {bill.TotalPrice}");
            Console.WriteLine($"Cash Tendered: {bill.CashTendered}");
            Console.WriteLine($"Change: {bill.ChangeAmount}");
        }
    }
}
