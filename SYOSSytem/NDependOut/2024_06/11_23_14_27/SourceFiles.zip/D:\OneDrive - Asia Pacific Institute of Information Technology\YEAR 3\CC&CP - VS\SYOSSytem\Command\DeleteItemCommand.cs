﻿using SYOSSytem.DataGateway;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class DeleteItemCommand : ICommand
    {
        private string itemCode;
        private ItemGateway itemGateway;

        public DeleteItemCommand(string itemCode, ItemGateway itemGateway)
        {
            this.itemCode = itemCode;
            this.itemGateway = itemGateway;
        }

        public void Execute()
        {
            itemGateway.DeleteItem(itemCode);
        }
    }
}
