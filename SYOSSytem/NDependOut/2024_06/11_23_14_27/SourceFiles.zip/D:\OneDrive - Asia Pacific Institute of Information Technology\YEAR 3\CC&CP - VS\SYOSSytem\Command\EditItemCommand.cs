﻿using SYOSSytem.DataGateway;
using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class EditItemCommand : ICommand
    {
        private ItemDTO item;
        private ItemGateway itemGateway;

        public EditItemCommand(ItemDTO item, ItemGateway itemGateway)
        {
            this.item = item;
            this.itemGateway = itemGateway;
        }

        public void Execute()
        {
            itemGateway.EditItem(item);
        }
    }
}
