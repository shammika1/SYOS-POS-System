﻿using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Template
{
    public class DailySalesReport : Report
    {
        private DateTime date;

        public DailySalesReport(DateTime date)
        {
            this.date = date;
        }

        protected override List<object> GetReportData()
        {
            return reportGateway.GetDailySalesReport(date).Cast<object>().ToList();
        }

        protected override void DisplayReport(List<object> data)
        {
            var salesData = data.Cast<SalesReportDTO>().ToList();
            Console.WriteLine("Daily Sales Report:");
            Console.WriteLine("Item Code\tItem Name\tTotal Quantity\tTotal Revenue");
            foreach (var item in salesData)
            {
                Console.WriteLine($"{item.ItemCode}\t{item.ItemName}\t{item.TotalQuantity}\t{item.TotalRevenue}");
            }
        }
    }
}
