﻿using SYOSSytem.DataGateway;
using SYOSSytem.Decorator;
using SYOSSytem.DTO;
using SYOSSytem.Factory;
using SYOSSytem.State;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Facade
{
    public class BillingFacade
    {
        private InventoryFacade inventoryFacade;
        private BillGateway billGateway;
        private BillItemGateway billItemGateway;

        

        public BillingFacade()
        {
            inventoryFacade = new InventoryFacade();
            billGateway = new BillGateway();
            billItemGateway = new BillItemGateway();
        }

        public void Configure(InventoryFacade inventoryFacade, BillGateway billGateway, BillItemGateway billItemGateway)
        {
            this.inventoryFacade = inventoryFacade;
            this.billGateway = billGateway;
            this.billItemGateway = billItemGateway;
        }

        public void ProcessSale()
        {
            BillingContext billingContext = new BillingContext(inventoryFacade, billGateway, billItemGateway);
            billingContext.SetState(new ItemEntryState());
        }
    }
}
