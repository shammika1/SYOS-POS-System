﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Composite
{
    public interface IItemComponent
    {
        void Display(int depth);
    }
}
