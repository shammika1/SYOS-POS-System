﻿using Microsoft.Data.SqlClient;
using SYOSSytem.DTO;
using SYOSSytem.Singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.DataGateway
{
    public class StockGateway
    {
        public void AddStock(StockDTO stock)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "INSERT INTO Stock (ItemCode, Quantity, ExpiryDate, DateOfPurchase) VALUES (@ItemCode, @Quantity, @ExpiryDate, @DateOfPurchase)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ItemCode", stock.ItemCode);
                command.Parameters.AddWithValue("@Quantity", stock.Quantity);
                command.Parameters.AddWithValue("@ExpiryDate", stock.ExpiryDate);
                command.Parameters.AddWithValue("@DateOfPurchase", stock.DateOfPurchase);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void DeleteStock(int stockID)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "DELETE FROM Stock WHERE StockID = @StockID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StockID", stockID);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public List<StockDTO> GetAllStocks()
        {
            List<StockDTO> stocks = new List<StockDTO>();
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT StockID, ItemCode, Quantity, ExpiryDate FROM Stock";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    stocks.Add(new StockDTO
                    {
                        StockID = Convert.ToInt32(reader["StockID"]),
                        ItemCode = reader["ItemCode"].ToString(),
                        Quantity = Convert.ToInt32(reader["Quantity"]),
                        ExpiryDate = reader["ExpiryDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["ExpiryDate"])
                    });
                }
            }
            return stocks;
        }

        public List<StockDTO> GetStocksByItemCode(string itemCode)
        {
            List<StockDTO> stocks = new List<StockDTO>();
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT * FROM Stock WHERE ItemCode = @ItemCode";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ItemCode", itemCode);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    stocks.Add(new StockDTO
                    {
                        StockID = Convert.ToInt32(reader["StockID"]),
                        ItemCode = reader["ItemCode"].ToString(),
                        Quantity = Convert.ToInt32(reader["Quantity"]),
                        ExpiryDate = reader["ExpiryDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["ExpiryDate"])
                    });
                }
            }
            return stocks;
        }

        public void UpdateStock(StockDTO stock)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "UPDATE Stock SET Quantity = @Quantity WHERE StockID = @StockID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Quantity", stock.Quantity);
                command.Parameters.AddWithValue("@StockID", stock.StockID);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
