﻿using SYOSSytem.DataGateway;
using SYOSSytem.DTO;
using SYOSSytem.Facade;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.State
{
    public class BillingContext
    {
        private IBillingState _state;

        public InventoryFacade InventoryFacade { get; set; }
        public BillGateway BillGateway { get; set; }
        public BillItemGateway BillItemGateway { get; set; }

        public List<BillItemDTO> BillItems { get; set; }
        public decimal Discount { get; set; }
        public decimal CashTendered { get; set; }

        public BillingContext(InventoryFacade inventoryFacade, BillGateway billGateway, BillItemGateway billItemGateway)
        {
            InventoryFacade = inventoryFacade;
            BillGateway = billGateway;
            BillItemGateway = billItemGateway;
            SetState(new ItemEntryState());
        }

        public void SetState(IBillingState state)
        {
            _state = state;
            _state.Handle(this);
        }

        public IBillingState CurrentState()
        {
            return _state;
        }
    }

}
