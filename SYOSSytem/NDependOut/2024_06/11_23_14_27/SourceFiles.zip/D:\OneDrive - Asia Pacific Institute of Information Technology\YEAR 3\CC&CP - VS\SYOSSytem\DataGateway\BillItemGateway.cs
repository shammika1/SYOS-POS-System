﻿using Microsoft.Data.SqlClient;
using SYOSSytem.DTO;
using SYOSSytem.Singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.DataGateway
{
    public class BillItemGateway
    {
        public void AddBillItem(BillItemDTO billItem)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "INSERT INTO BillItem (BillID, ItemCode, ItemName, Quantity, TotalPrice) VALUES (@BillID, @ItemCode, @ItemName, @Quantity, @TotalPrice)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@BillID", billItem.BillID);
                command.Parameters.AddWithValue("@ItemCode", billItem.ItemCode);
                command.Parameters.AddWithValue("@ItemName", billItem.ItemName);
                command.Parameters.AddWithValue("@Quantity", billItem.Quantity);
                command.Parameters.AddWithValue("@TotalPrice", billItem.TotalPrice);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
