﻿using SYOSSytem.DTO;
using SYOSSytem.Factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.State
{
    public class ItemEntryState : IBillingState
    {
        public void Handle(BillingContext context)
        {
            List<BillItemDTO> billItems = new List<BillItemDTO>();

            while (true)
            {
                Console.Write("Enter item code (or '00' to finish): ");
                string itemCode = Console.ReadLine();

                if (itemCode == "00")
                {
                    break;
                }

                Console.Write("Enter quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                ItemDTO item = context.InventoryFacade.GetItem(itemCode);

                if (item != null)
                {
                    BillItemDTO billItem = DTOFactory.CreateBillItemDTO(null, item.ItemCode, item.Name, quantity, item.Price * quantity);
                    billItems.Add(billItem);
                }
                else
                {
                    Console.WriteLine("Item not found.");
                }
            }

            context.BillItems = billItems;
            context.SetState(new PaymentState());
        }
    }

}
