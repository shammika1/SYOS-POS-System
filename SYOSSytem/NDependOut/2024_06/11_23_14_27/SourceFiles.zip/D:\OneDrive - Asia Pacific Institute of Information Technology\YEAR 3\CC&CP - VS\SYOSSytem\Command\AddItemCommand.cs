﻿using SYOSSytem.DataGateway;
using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class AddItemCommand : ICommand
    {
        private ItemDTO item;
        private ItemGateway itemGateway;

        public AddItemCommand(ItemDTO item, ItemGateway itemGateway)
        {
            this.item = item;
            this.itemGateway = itemGateway;
        }

        public void Execute()
        {
            itemGateway.AddItem(item);
        }
    }
}
