﻿using SYOSSytem.DataGateway;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Template
{
    public abstract class Report
    {
        protected ReportGateway reportGateway;

        public Report()
        {
            reportGateway = new ReportGateway();
        }

        public void GenerateReport()
        {
            var data = GetReportData();
            DisplayReport(data);
        }

        protected abstract List<object> GetReportData();
        protected abstract void DisplayReport(List<object> data);
    }
}
