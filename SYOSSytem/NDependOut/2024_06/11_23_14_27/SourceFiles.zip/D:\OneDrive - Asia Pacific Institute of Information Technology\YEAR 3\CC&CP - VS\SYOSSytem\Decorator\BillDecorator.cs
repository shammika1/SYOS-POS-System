﻿using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Decorator
{
    public abstract class BillDecorator : BillDTO
    {
        protected BillDTO bill;

        public BillDecorator(BillDTO bill)
        {
            this.bill = bill;
        }

        public override decimal TotalPrice
        {
            get { return bill.TotalPrice; }
            set { bill.TotalPrice = value; }
        }

        public override decimal Discount
        {
            get { return bill.Discount; }
            set { bill.Discount = value; }
        }

    }
}
