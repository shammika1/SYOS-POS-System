﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Composite
{
    public class ItemLeaf : IItemComponent
    {
        public string ItemCode { get; private set; }
        public string Name { get; private set; }

        public ItemLeaf(string itemCode, string name)
        {
            ItemCode = itemCode;
            Name = name;
        }

        public void Display(int depth)
        {
            Console.WriteLine(new string('-', depth) + $"{Name} (Code: {ItemCode}");
        }
    }


}
