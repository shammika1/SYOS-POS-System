﻿using SYOSSytem.DataGateway;
using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class AddStockCommand : ICommand
    {
        private StockDTO stock;
        private StockGateway stockGateway;

        public AddStockCommand(StockDTO stock, StockGateway stockGateway)
        {
            this.stock = stock;
            this.stockGateway = stockGateway;
        }

        public void Execute()
        {
            stockGateway.AddStock(stock);
        }
    }
}
