﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.State
{
    public abstract class BillingState
    {
        protected BillingContext context;

        public void SetContext(BillingContext context)
        {
            this.context = context;
        }

        public abstract void Handle();
    }
}
