﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.DTO
{
    public class ReorderReportDTO
    {
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public int RemainingQuantity { get; set; }
    }
}
