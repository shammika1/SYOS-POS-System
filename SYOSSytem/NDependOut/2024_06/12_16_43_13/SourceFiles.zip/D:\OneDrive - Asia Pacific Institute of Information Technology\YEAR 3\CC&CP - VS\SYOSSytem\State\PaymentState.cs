﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.State
{
    public class PaymentState : IBillingState
    {
        public void Handle(BillingContext context)
        {
            Console.WriteLine("\nPreview of Items:");
            Console.WriteLine("Item Name\tQuantity\tPrice\tTotal Price");

            foreach (var billItem in context.BillItems)
            {
                Console.WriteLine($"{billItem.ItemName}\t{billItem.Quantity}\t{billItem.TotalPrice / billItem.Quantity}\t{billItem.TotalPrice}");
            }

            decimal totalPrice = context.BillItems.Sum(item => item.TotalPrice);
            Console.WriteLine($"Total Price: {totalPrice}");

            Console.Write("Enter discount: ");
            decimal discount = decimal.Parse(Console.ReadLine());

            Console.Write("Enter cash tendered: ");
            decimal cashTendered = decimal.Parse(Console.ReadLine());

            context.Discount = discount;
            context.CashTendered = cashTendered;

            context.SetState(new ReceiptGenerationState());
        }
    }

}
