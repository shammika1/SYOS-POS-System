﻿using SYOSSytem.Builder;
using SYOSSytem.Command;
using SYOSSytem.Decorator;
using SYOSSytem.DTO;
using SYOSSytem.Factory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.State
{
    public class ReceiptGenerationState : IBillingState
    {
        public void Handle(BillingContext context)
        {
            ICommand processSaleCommand = CommandFactory.CreateProcessSaleCommand(context);
            processSaleCommand.Execute();
        }
    }

}


