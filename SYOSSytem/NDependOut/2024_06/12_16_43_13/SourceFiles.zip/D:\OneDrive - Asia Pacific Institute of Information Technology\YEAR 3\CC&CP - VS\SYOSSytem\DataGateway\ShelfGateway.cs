﻿using Microsoft.Data.SqlClient;
using SYOSSytem.DTO;
using SYOSSytem.Singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.DataGateway
{
    public class ShelfGateway
    {
        public void AddShelf(ShelfDTO shelf)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "INSERT INTO Shelf (ShelfLocation, ShelfQuantity, ItemID) VALUES (@ShelfLocation, @ShelfQuantity, @ItemID)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ShelfLocation", shelf.ShelfLocation);
                command.Parameters.AddWithValue("@ShelfQuantity", shelf.ShelfQuantity);
                command.Parameters.AddWithValue("@ItemID", shelf.ItemCode);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void DeleteShelf(int shelfID)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "DELETE FROM Shelf WHERE ShelfID = @ShelfID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ShelfID", shelfID);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public List<ShelfDTO> GetAllShelves()
        {
            List<ShelfDTO> shelves = new List<ShelfDTO>();
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT * FROM Shelf";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    shelves.Add(new ShelfDTO
                    {
                        ShelfID = Convert.ToInt32(reader["ShelfID"]),
                        ShelfLocation = reader["ShelfLocation"].ToString(),
                        ShelfQuantity = Convert.ToInt32(reader["ShelfQuantity"]),
                        ItemCode = reader["ItemID"].ToString()
                    });
                }
            }
            return shelves;
        }

        public ShelfDTO GetShelfById(int shelfID)
        {
            ShelfDTO shelf = null;
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT * FROM Shelf WHERE ShelfID = @ShelfID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ShelfID", shelfID);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    shelf = new ShelfDTO
                    {
                        ShelfID = Convert.ToInt32(reader["ShelfID"]),
                        ShelfLocation = reader["ShelfLocation"].ToString(),
                        ShelfQuantity = Convert.ToInt32(reader["ShelfQuantity"]),
                        ItemCode = reader["ItemID"].ToString()
                    };
                }
            }
            return shelf;
        }

        public List<ShelfDTO> GetShelvesByItemCode(string itemCode)
        {
            List<ShelfDTO> shelves = new List<ShelfDTO>();
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT * FROM Shelf WHERE ItemID = @ItemID ORDER BY ShelfLocation";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ItemID", itemCode);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    shelves.Add(new ShelfDTO
                    {
                        ShelfID = Convert.ToInt32(reader["ShelfID"]),
                        ShelfLocation = reader["ShelfLocation"].ToString(),
                        ShelfQuantity = Convert.ToInt32(reader["ShelfQuantity"]),
                        ItemCode = reader["ItemID"].ToString()
                    });
                }
            }
            return shelves;
        }

        public void UpdateShelf(ShelfDTO shelf)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "UPDATE Shelf SET ShelfQuantity = @ShelfQuantity WHERE ShelfID = @ShelfID";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ShelfQuantity", shelf.ShelfQuantity);
                command.Parameters.AddWithValue("@ShelfID", shelf.ShelfID);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
