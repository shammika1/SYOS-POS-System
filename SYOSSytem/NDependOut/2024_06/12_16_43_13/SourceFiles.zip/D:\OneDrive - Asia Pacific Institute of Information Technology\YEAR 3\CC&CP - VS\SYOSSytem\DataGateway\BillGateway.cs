﻿using Microsoft.Data.SqlClient;
using SYOSSytem.DTO;
using SYOSSytem.Singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.DataGateway
{
    public class BillGateway
    {
        public void AddBill(BillDTO bill)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                bill.BillID = GenerateUniqueBillID(connection);

                string query = "INSERT INTO Bill (BillID, Date, TotalPrice, Discount, CashTendered, ChangeAmount) VALUES (@BillID, @Date, @TotalPrice, @Discount, @CashTendered, @ChangeAmount)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@BillID", bill.BillID);
                command.Parameters.AddWithValue("@Date", bill.Date);
                command.Parameters.AddWithValue("@TotalPrice", bill.TotalPrice);
                command.Parameters.AddWithValue("@Discount", bill.Discount);
                command.Parameters.AddWithValue("@CashTendered", bill.CashTendered);
                command.Parameters.AddWithValue("@ChangeAmount", bill.ChangeAmount);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private string GenerateUniqueBillID(SqlConnection connection)
        {
            string datePart = DateTime.Now.ToString("yyyyMMdd");
            string query = "SELECT COUNT(*) FROM Bill WHERE BillID LIKE @BillIDPattern";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@BillIDPattern", datePart + "-%");

            connection.Open();
            int count = (int)command.ExecuteScalar();
            connection.Close();

            string serialNumber = (count + 1).ToString("D4");
            return $"{datePart}-{serialNumber}";
        }

        public List<BillDTO> GetAllBills()
        {
            List<BillDTO> bills = new List<BillDTO>();

            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT * FROM Bill";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    BillDTO bill = new BillDTO
                    {
                        BillID = reader["BillID"].ToString(),
                        Date = Convert.ToDateTime(reader["Date"]),
                        TotalPrice = Convert.ToDecimal(reader["TotalPrice"]),
                        Discount = Convert.ToDecimal(reader["Discount"]),
                        CashTendered = Convert.ToDecimal(reader["CashTendered"]),
                        ChangeAmount = Convert.ToDecimal(reader["ChangeAmount"])
                    };
                    bills.Add(bill);
                }
            }
            return bills;
        }
    }
}
