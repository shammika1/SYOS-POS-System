﻿using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Template
{
    public class ReorderReport : Report
    {
        protected override List<object> GetReportData()
        {
            return reportGateway.GetReorderReport().Cast<object>().ToList();
        }

        protected override void DisplayReport(List<object> data)
        {
            var reorderData = data.Cast<ReorderReportDTO>().ToList();
            Console.WriteLine("Reorder Report:");
            Console.WriteLine("Item Code\tItem Name\tRemaining Quantity");
            foreach (var item in reorderData)
            {
                Console.WriteLine($"{item.ItemCode}\t{item.ItemName}\t{item.RemainingQuantity}");
            }
        }
    }
}
