﻿using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Template
{
    public class ReshelvingReport : Report
    {
        protected override List<object> GetReportData()
        {
            return reportGateway.GetReshelvingReport().Cast<object>().ToList();
        }

        protected override void DisplayReport(List<object> data)
        {
            var reshelvingData = data.Cast<ReshelvingReportDTO>().ToList();
            Console.WriteLine("Reshelving Report:");
            Console.WriteLine("Item Code\tItem Name\tQuantity to Reshelve");
            foreach (var item in reshelvingData)
            {
                Console.WriteLine($"{item.ItemCode}\t{item.ItemName}\t{item.Quantity}");
            }
        }
    }
}
