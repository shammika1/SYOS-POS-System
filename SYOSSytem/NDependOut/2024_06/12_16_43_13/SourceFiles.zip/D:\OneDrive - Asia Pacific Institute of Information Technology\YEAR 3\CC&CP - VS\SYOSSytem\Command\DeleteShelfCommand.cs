﻿using SYOSSytem.DataGateway;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class DeleteShelfCommand : ICommand
    {
        private int shelfID;
        private ShelfGateway shelfGateway;

        public DeleteShelfCommand(int shelfID, ShelfGateway shelfGateway)
        {
            this.shelfID = shelfID;
            this.shelfGateway = shelfGateway;
        }

        public void Execute()
        {
            shelfGateway.DeleteShelf(shelfID);
        }
    }
}
