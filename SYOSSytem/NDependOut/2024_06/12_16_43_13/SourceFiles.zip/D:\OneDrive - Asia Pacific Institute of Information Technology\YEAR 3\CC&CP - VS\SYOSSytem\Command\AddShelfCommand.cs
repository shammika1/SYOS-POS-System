﻿using SYOSSytem.DataGateway;
using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class AddShelfCommand : ICommand
    {
        private ShelfDTO shelf;
        private ShelfGateway shelfGateway;

        public AddShelfCommand(ShelfDTO shelf, ShelfGateway shelfGateway)
        {
            this.shelf = shelf;
            this.shelfGateway = shelfGateway;
        }

        public void Execute()
        {
            shelfGateway.AddShelf(shelf);
        }
    }
}
