﻿using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Decorator
{
    public class DiscountDecorator : BillDecorator
    {
        public DiscountDecorator(BillDTO bill, decimal discount) : base(bill)
        {
            this.bill.Discount = discount;
        }

        public override decimal TotalPrice
        {
            get { return base.TotalPrice - base.Discount; }
        }
    }

}
