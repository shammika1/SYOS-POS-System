﻿using SYOSSytem.Template;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Builder
{
    public class ReportBuilder
    {
        private Report report;

        public ReportBuilder SetReport(Report report)
        {
            this.report = report;
            return this;
        }

        public Report Build()
        {
            return report;
        }
    }

}
