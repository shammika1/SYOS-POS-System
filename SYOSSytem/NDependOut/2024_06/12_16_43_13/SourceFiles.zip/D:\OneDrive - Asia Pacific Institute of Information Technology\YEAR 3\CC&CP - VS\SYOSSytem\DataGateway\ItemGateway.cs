﻿using Microsoft.Data.SqlClient;
using SYOSSytem.DTO;
using SYOSSytem.Singleton;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.DataGateway
{
    public class ItemGateway
    {
        public void AddItem(ItemDTO item)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "INSERT INTO Item (ItemCode, Name, Price) VALUES (@ItemCode, @Name, @Price)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ItemCode", item.ItemCode);
                command.Parameters.AddWithValue("@Name", item.Name);
                command.Parameters.AddWithValue("@Price", item.Price);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void EditItem(ItemDTO item)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "UPDATE Item SET Name = @Name, Price = @Price WHERE ItemCode = @ItemCode";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ItemCode", item.ItemCode);
                command.Parameters.AddWithValue("@Name", item.Name);
                command.Parameters.AddWithValue("@Price", item.Price);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void DeleteItem(string itemCode)
        {
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "DELETE FROM Item WHERE ItemCode = @ItemCode";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ItemCode", itemCode);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public List<ItemDTO> GetAllItems()
        {
            List<ItemDTO> items = new List<ItemDTO>();
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT * FROM Item";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    items.Add(new ItemDTO
                    {
                        ItemCode = reader["ItemCode"].ToString(),
                        Name = reader["Name"].ToString(),
                        Price = Convert.ToDecimal(reader["Price"])
                    });
                }
            }
            return items;
        }

        public ItemDTO GetItem(string itemCode)
        {
            ItemDTO item = null;
            using (SqlConnection connection = new SqlConnection(DatabaseConnection.Instance.ConnectionString))
            {
                string query = "SELECT * FROM Item WHERE ItemCode = @ItemCode";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ItemCode", itemCode);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    item = new ItemDTO
                    {
                        ItemCode = reader["ItemCode"].ToString(),
                        Name = reader["Name"].ToString(),
                        Price = Convert.ToDecimal(reader["Price"]),
                    };
                }
            }
            return item;
        }
    }
}
