﻿using SYOSSytem.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Template
{
    public class BillReport : Report
    {
        protected override List<object> GetReportData()
        {
            return reportGateway.GetBillReport().Cast<object>().ToList();
        }

        protected override void DisplayReport(List<object> data)
        {
            var billData = data.Cast<BillReportDTO>().ToList();
            Console.WriteLine("Bill Report:");
            Console.WriteLine("Bill ID\tDate\tTotal Price\tDiscount\tCash Tendered\tChange Amount");
            foreach (var item in billData)
            {
                Console.WriteLine($"{item.BillID}\t{item.Date}\t{item.TotalPrice}\t{item.Discount}\t{item.CashTendered}\t{item.ChangeAmount}");
            }
        }
    }
}
