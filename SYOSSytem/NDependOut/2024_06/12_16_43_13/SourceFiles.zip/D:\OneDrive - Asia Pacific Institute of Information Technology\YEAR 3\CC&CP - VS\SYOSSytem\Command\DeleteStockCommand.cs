﻿using SYOSSytem.DataGateway;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYOSSytem.Command
{
    public class DeleteStockCommand : ICommand
    {
        private int stockID;
        private StockGateway stockGateway;

        public DeleteStockCommand(int stockID, StockGateway stockGateway)
        {
            this.stockID = stockID;
            this.stockGateway = stockGateway;
        }

        public void Execute()
        {
            stockGateway.DeleteStock(stockID);
        }
    }
}
