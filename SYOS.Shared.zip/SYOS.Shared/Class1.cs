﻿namespace SYOS.Shared;

public class Class1
{
}