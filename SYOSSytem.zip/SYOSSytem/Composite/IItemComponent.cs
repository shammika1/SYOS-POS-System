﻿namespace SYOSSytem.Composite;

public interface IItemComponent
{
    void Display(int depth);
}