﻿namespace SYOSSytem.DTO;

public class ItemDTO
{
    public string ItemCode { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
    public string Category { get; set; }
}